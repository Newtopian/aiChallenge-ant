
public enum ImpulseTypes {

	HUNGER,
	DISCOVERY;
}
