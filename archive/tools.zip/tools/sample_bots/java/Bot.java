public interface Bot {
	void do_turn(Ants ants);
}
